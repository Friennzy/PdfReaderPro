package com.rejowan.pdfreaderpro.interfaces

interface ChildFragmentsCommunication {
    fun onFolderSelected(folder: String)
}
