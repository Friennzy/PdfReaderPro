package com.rejowan.pdfreaderpro.enums

enum class PermissionStatus {
    INITIAL, GRANTED, DENIED
}