package com.rejowan.pdfreaderpro.constants

class Constants {

    companion object {

        val contactEmail = "kmrejowan@gmail.com"
        val sourceCode = "https://github.com/ahmmedrejowan/PDF-Reader-Pro"
        val portfolio = "https://rejowan.com"
        val appVersion = "1.0"
        val companyName = "K M Rejowan Ahmmed"

    }

}