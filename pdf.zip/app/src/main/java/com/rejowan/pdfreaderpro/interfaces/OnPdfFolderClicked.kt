package com.rejowan.pdfreaderpro.interfaces

interface OnPdfFolderClicked {
    fun onPdfFolderClicked(folderName: String)
}